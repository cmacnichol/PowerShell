#requires -Version 3 -Modules ActiveDirectory
<#
    .Synopsis
    Add User to Creative Cloud Active Directory Group
   
    .DESCRIPTION
    This script will prompt for an individual User ID or take a Text file of User ID and Add\Remove them from the Creative Cloud Active Driectory group.  
   
    .EXAMPLE

    .INPUTS
    Inputs to this cmdlet (if any)

    .OUTPUTS
    Output from this cmdlet (if any)       

    .NOTES
    
    Requires: Powershell 3.0
    Active-Directory Module

    Author          : Chris Macnichol
    Version         : 0.1
    Version History : 
                      0.1 - Initial Script With Add Group and Logging Functionality.  GUI Working.
    Created         : 01/23/2017
    Last updated    : 01/23/2017
#>
    [CmdletBinding(DefaultParameterSetName='Parameter Set 1', 
                  SupportsShouldProcess=$true, 
                  PositionalBinding=$false,
                  ConfirmImpact='Medium')]
    [Alias()]
    [OutputType([String])]
    Param
    (
        # Param1 help description
        [Parameter(Mandatory=$false, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0,
                   ParameterSetName='Parameter Set 1')]
        [Alias('UserList')] 
        $UserFile = $null
    )

    Begin
    {
      ##Declare Default Variables
      #Current Script Path
      [string]$scriptDir = Convert-Path -Path .
      #Log File Name
      [string]$logdir = "$PSScriptRoot\AddRemove-UserAdGroup.log"
      #User File Name
      if ($userFile -eq $null) {[string]$UserFile = "$PSScriptRoot\Users.csv"}
      # AD Group to Add or Remove Users From
      $Script:ADGroupR = 'R_CreativeCloud_DL'
      $Script:ADGroupI = 'I_CreativeCloud_DG'
      #Clear Users Variable
      $users = $null

      #Log File Function
      function Write-Log {
    <#
        .Synopsis 
        Write-Log writes a message to a specified log file with the current time stamp. 
        .DESCRIPTION 
        The Write-Log function is designed to add logging capability to other scripts. 
        In addition to writing output and/or verbose you can write to a log file for 
        later debugging. 
        .NOTES 
        Created by: Jason Wasser @wasserja 
        Modified: 11/24/2015 09:30:19 AM   
 
        Changelog: 
        * Code simplification and clarification - thanks to @juneb_get_help 
        * Added documentation. 
        * Renamed LogPath parameter to Path to keep it standard - thanks to @JeffHicks 
        * Revised the Force switch to work as it should - thanks to @JeffHicks 
 
        To Do: 
        * Add error handling if trying to create a log file in a inaccessible location. 
        * Add ability to write $Message to $Verbose or $Error pipelines to eliminate 
        duplicates. 
        .PARAMETER Message 
        Message is the content that you wish to add to the log file.  
        .PARAMETER Path 
        The path to the log file to which you would like to write. By default the function will  
        create the path and file if it does not exist.  
        .PARAMETER Level 
        Specify the criticality of the log information being written to the log (i.e. Error, Warning, Informational) 
        .PARAMETER NoClobber 
        Use NoClobber if you do not wish to overwrite an existing file. 
        .EXAMPLE 
        Write-Log -Message 'Log message'  
        Writes the message to c:\Logs\PowerShellLog.log. 
        .EXAMPLE 
        Write-Log -Message 'Restarting Server.' -Path c:\Logs\Scriptoutput.log 
        Writes the content to the specified log file and creates the path and file specified.  
        .EXAMPLE 
        Write-Log -Message 'Folder does not exist.' -Path c:\Logs\Script.log -Level Error 
        Writes the message to the specified log file as an error message, and writes the message to the error pipeline. 
        .LINK 
        https://gallery.technet.microsoft.com/scriptcenter/Write-Log-PowerShell-999c32d0 
    #>
    
    [CmdletBinding()] 
    Param 
    ( 
      [Parameter(Mandatory = $True, 
      ValueFromPipelineByPropertyName = $True)] 
      [ValidateNotNullOrEmpty()] 
      [Alias('LogContent')] 
      [string]$Message, 
 
      [Parameter(Mandatory = $false)] 
      [Alias('Path')] 
      [string]$logpath = "$script:LogDir", 
         
      [Parameter(Mandatory = $false)] 
      [ValidateSet('Error','Warn','Info')] 
      [string]$Level = 'Info', 
         
      [Parameter(Mandatory = $false)] 
      [switch]$NoClobber 
    ) 
 
    Begin 
    { 
       
      # Set VerbosePreference to Continue so that verbose messages are displayed. 
      $VerbosePreference = 'Continue'
      $ConfirmPreference = 'None'
      $WhatIfPreference = $false
    } 
    Process 
    { 
         
      # If the file already exists and NoClobber was specified, do not write to the log. 
      if ((Test-Path -Path $logpath) -AND $NoClobber) 
      { 
        Write-log -Message "Log file $logpath already exists, and you specified NoClobber. Either delete the file or specify a different name." -Level Error
        Return 
      } 
 
      # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path. 
      elseif (!(Test-Path -Path $logpath)) 
      { 
        Write-Verbose -Message "Creating $logpath." 
        $NewLogFile = New-Item -Path $logpath -Force -ItemType File 
      } 
 
      else 
      {
        # Nothing to see here yet. 
      } 
 
      # Format Date for our Log File 
      $FormattedDate = Get-Date -Format 'yyyy-MM-dd HH:mm:ss' 
 
      # Write message to error, warning, or verbose pipeline and specify $LevelText 
      switch ($Level) { 
        'Error' 
        { 
          Write-Error -Message $Message 
          $LevelText = 'ERROR:' 
        } 
        'Warn' 
        { 
          Write-Warning -Message $Message 
          $LevelText = 'WARNING:' 
        } 
        'Info' 
        { 
          Write-Verbose -Message $Message 
          $LevelText = 'INFO:' 
        } 
      } 
         
      # Write log entry to $logpath 
      "$FormattedDate $LevelText $Message" | Out-File -FilePath $logpath -Append 
    } 
    End 
    { 
    } 
  }

      # A function to create the form 
      function Input-Form{
    [void] [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
    [void] [System.Reflection.Assembly]::LoadWithPartialName('System.Drawing') 
    
    #Create an hashtable variable to return results
    [array]$Return = @{}
    $input = $null

    # Set the size of your form
    $Form = New-Object -TypeName System.Windows.Forms.Form
    $Form.Size = New-Object -TypeName System.Drawing.Size -ArgumentList (500,300) 
    $Form.Text = 'Add\Remove user from Active Directory Group'
    $Form.StartPosition = 'CenterScreen'

    # Set the font of the text to be used within the form
    $Font = New-Object -TypeName System.Drawing.Font -ArgumentList ('Times New Roman',12)
    $Form.Font = $Font
 
    # Create a group that will contain your radio buttons
    $MyGroupBox = New-Object -TypeName System.Windows.Forms.GroupBox
    $MyGroupBox.Location = '40,30'
    $MyGroupBox.size = '400,80'
    $MyGroupBox.text = 'Add\Remove'
    
    # Create the collection of radio buttons
    $RadioButton1 = New-Object -TypeName System.Windows.Forms.RadioButton
    $RadioButton1.Location = '20,40'
    $RadioButton1.size = '120,20'
    $RadioButton1.Checked = $true 
    $RadioButton1.Text = 'Add'
 
    $RadioButton2 = New-Object -TypeName System.Windows.Forms.RadioButton
    $RadioButton2.Location = '160,40'
    $RadioButton2.size = '120,20'
    $RadioButton2.Checked = $false
    $RadioButton2.Text = 'Remove'
   
    $objLabel = New-Object -TypeName System.Windows.Forms.Label
    $objLabel.Location = New-Object -TypeName System.Drawing.Size -ArgumentList (40,120) 
    $objLabel.Size = New-Object -TypeName System.Drawing.Size -ArgumentList (400,20) 
    $objLabel.Text = 'Please enter the User ID you would like to Add\Remove.'
    $Form.Controls.Add($objLabel)

    $objEx = New-Object -TypeName System.Windows.Forms.Label
    $objEx.Location = New-Object -TypeName System.Drawing.Size -ArgumentList (180,145) 
    $objEx.Size = New-Object -TypeName System.Drawing.Size -ArgumentList (400,20) 
    $objEx.Text = 'EX: HBxxxxx'
    $Form.Controls.Add($objEx)

    $objTextBox = New-Object -TypeName System.Windows.Forms.TextBox 
    $objTextBox.Location = New-Object -TypeName System.Drawing.Size -ArgumentList (150,170) 
    $objTextBox.Size = New-Object -TypeName System.Drawing.Size -ArgumentList (175,20) 
    $Form.Controls.Add($objTextBox)

    # Add an OK button
    # Thanks to J.Vierra for simplifing the use of buttons in forms
    $OKButton = new-object -TypeName System.Windows.Forms.Button
    $OKButton.Location = '130,200'
    $OKButton.Size = '100,40' 
    $OKButton.Text = 'OK'
    $OKButton.DialogResult=[System.Windows.Forms.DialogResult]::OK
 
    #Add a cancel button
    $CancelButton = new-object -TypeName System.Windows.Forms.Button
    $CancelButton.Location = '255,200'
    $CancelButton.Size = '100,40'
    $CancelButton.Text = 'Cancel'
    $CancelButton.DialogResult=[System.Windows.Forms.DialogResult]::Cancel
 
    # Add all the Form controls on one line 
    $form.Controls.AddRange(@($MyGroupBox,$OKButton,$CancelButton))
 
    # Add all the GroupBox controls on one line
    $MyGroupBox.Controls.AddRange(@($Radiobutton1,$RadioButton2))
    
    # Assign the Accept and Cancel options in the form to the corresponding buttons
    $form.AcceptButton = $OKButton
    $form.CancelButton = $CancelButton

    # Puts the form on top
    $Form.Topmost = $True

    # Activate the form
    $form.Add_Shown({$form.Activate()})    
    
    # Get the results from the button click
    $dialogResult = $form.ShowDialog()
 
    # If the OK button is selected
    if ($dialogResult -eq 'OK'){
        
        # Check the current state of each radio button and respond accordingly
        if ($RadioButton1.Checked){

          # Create Array to Store results
          $Return = [PSCustomObject]@{
          Action  = $RadioButton1.Text
          User    = $objTextBox.Text
          }#EndPSCustomObject

           }
        elseif ($RadioButton2.Checked){

          # Create Array to Store results
          $Return = [PSCustomObject]@{
          Action  = $RadioButton2.Text
          User    = $objTextBox.Text
          }#EndPSCustomObject
              
              }
    }

    Return $return
}

      # Add User to AD Group
      function Add-UserToGroup {
      
      param
      (
        [String]
        $User = $null,
      
        [String]
        $adGroup = $null
      )
      
      if ($user -eq $null) {Write-Log -Message 'User Input Empty, Skipping' -Level Warn}

      # Set AD Group to add\remove if not specified
      if (!($adGroup)) {$adgroup = $Script:ADGroupI}

      $group = Get-ADGroup -Identity $adGroup -Server 'hbiusers.hbicorp.huntington.com'
      
      try {$UserObj = Get-ADUser -Server hbiusers.hbicorp.huntington.com -Identity $User -ErrorAction Stop}catch{Write-Log -Message "Error Getting User Details for: $User.  Skipping." -Level Error;return}

      Write-Log -Message "Checking if $($UserObj.name) is already a member of $adgroup"
      if (!((Get-ADUser -Server hbiusers.hbicorp.huntington.com -Identity $($UserObj.SamAccountName) -Properties MemberOf).memberof -like "$($group.name)"))
      {
      
      Write-Log -Message "User is not a member of $($group.name)"
      Write-Log -Message "Adding $user to $($group.name)"
      
      Try {
        if ($pscmdlet.ShouldProcess("$($group.name)", 'Adding User to Group'))
        {

          #Add-ADGroupMember -Identity $Group.name -Members $($User.SamAccountName) -Server hbiusers.hbicorp.huntington.com -ErrorVariable addGrError -ErrorAction Stop   
          Write-Log -Message 'User Added Successfully'

        }
      }
      catch{
        Write-Log -Message "Unable to Add $($UserObj.name) to $($group.name)" -Level Warn
        Write-Log -Message $addGrError -Level Error
      }
    } Else{
    
        Write-Log -Message "$($UserObj.SamAccountName) is already a member of Group: $($Group.name)" -Level Warn

            }

      } # End Add user to Group

      Write-Log -Message '--------------------------------------------'
      Write-Log -Message "Beginning $($MyInvocation.InvocationName) on $($env:COMPUTERNAME) by $env:USERDOMAIN\$env:USERNAME" -Level Info
      Write-Log -Message "Script is running from: $scriptDir"
      Write-Log -Message "Log File: $logdir"
      Write-Log -Message '--------------------------------------------'
      Write-Log -Message 'Checking for User File to Process'
      
      
      
      #Import User File if it Exists
      if ($(Test-Path -Path $UserFile)) {

      $userFilePath = $UserFile
      Write-Log -Message "Found User File at: $UserFilePath"
         
      [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.VisualBasic")
      $choice = [Microsoft.VisualBasic.Interaction]::MsgBox("Would you like to use the user file located at: `n $UserFilePath",'YesNoCancel,Question', "Respond please")
    
      if ($choice -eq 'Yes') {
      $Users = Import-Csv -Path $UserFile
      Write-Log -Message 'Importing User File' -Level Info
      }
      elseif ($choice -eq 'No') {
      Write-Log -Message 'Declined to Import User File' -Level Info
      }
      
      } #end Test Path



      #Check For User Content
      if (!($users)) {

      Write-Log -Message 'Requesting Input'
      # Call the GUI function
      $Users = Input-Form
      Write-Log -Message "$($users.User) received from GUI"
      }

      else {} #End Else


    }
    Process
    {

    foreach ($item in $Users)
    {
      Write-Log -Message '--------------------------------------------'
      Write-Log -Message "Processing Action $($item.Action) for User $($item.User)" -Level Info
       
      if ($item.Action -eq 'Add') {
      Add-UserToGroup -User $item.User
      }
      elseif ($item.action -eq 'Remove') {
      Remove-UserToGroup -User $item.User
      }
      else{Write-Log -Message "Invalid Input. `n Action $($item.Action) `n User $($Item.User)"}

    }
    


    }
    End
    {
    Write-Log -Message 'Script Finished'
    }