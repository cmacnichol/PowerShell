<#
    .Synopsis
      Repair computer trust relationship.
   
    .DESCRIPTION
      

    .EXAMPLE
     

    .INPUTS
      

    .OUTPUTS
      

    .NOTES
     
    
    Author          : Chris Macnichol
    Version         : 0.1
    Version History : 
    0.1 - 08-31-2017 - Initial Script.

    Created         : 08/31/2017
    Last updated    : 08/31/2017
#>

#No Params or Error checking is currently implemented.
<#Param
(
  # Param1 help description
  [Parameter(Mandatory = $false, 
      ValueFromPipeline = $true,
      ValueFromPipelineByPropertyName = $true,
      Position = 0,
  ParameterSetName = 'Parameter Set 1')]
  [Alias('ALIAS')]
  $Param1 = $null
)
#>
$trust = $false

$cred = $(Get-Credential -Message 'Please enter Credential with authority to rejoin to the Domain.')

while ($trust -eq $false)
{
  if (!(Test-ComputerSecureChannel -Credential $cred -Repair))
  {
    Start-Sleep -Seconds 2
  }
  Else
  {
  $trust = $true
  }
}

Write-Host 'Trust Relationship Repaired'
