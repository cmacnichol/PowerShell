<#
      .SYNOPSIS
      Get-ManagedByGroups

      .DESCRIPTION
      Script will retrieve a list of AD Groups where the ManagedBy Attribute is empty and output it to a CSV File.
      With the 'Set' Switch the script will process the csv and set the ManagedBy Value on the group.
      - 
      .INPUT
      Set
      InputPath
      OutputPath

      .OUTPUT
      CSV Group List

      .EXAMPLE


      .NOTES
      - V0.1  Chris Macnichol (07/06/2016) Base Script

#>
[cmdletbinding(DefaultParameterSetName=’OutputPath’)]
param(   
    [Parameter(ParameterSetName=’OutputPath’,
            Mandatory=$False,  
      Position=0)]
    [string[]]$OutputPath = 'C:\Temp\ManagedByGroups.csv',
         
    [Parameter(ParameterSetName=’Set’,
            Mandatory=$False,  
      Position=0)]
    [string[]]$InputPath = 'C:\Temp\ManagedByGroups.csv',

    [Parameter(ParameterSetName=’Set’,
            Mandatory=$True,
      Position=1)]
    [Switch]$Set = $false
) 

begin
{

    # Define Search Base
    $ou = 'DC=hbiusers,DC=hbicorp,DC=huntington,DC=com'
    # Define Domain Controller
    $DC = 'pdwadsusers03.hbiusers.hbicorp.huntington.com'

    function Get-EmptyManagedByGroups  {
        param
        (
            [String]
            $OutputPath
        )

        #Hbanc Search
        #$groupsResultHbanc = Get-ADGroup -LDAPFilter '(&(sAMAccountNAme=*Admin*)(objectClass=group))' -Properties ManagedBy
        #Hbanc Export
        #$groupsResultHbanc | Export-CSV -Path C:\Temp\ManagedByGroups.csv -NoTypeInformation

        $groupsResultHbicorp = @(Get-ADGroup -Server $DC -SearchBase $ou -LDAPFilter '(&(sAMAccountNAme=*Admin*)(objectClass=group)(!(managedBy=*)))' -Properties ManagedBy, Description)
    
        $groupsResultHbicorp | Select-Object Name, DistinguishedName, Description, SamAccountName, ManagedBy | Export-CSV -Path $OutputPath -NoTypeInformation
    }


    function Set-EmptyManagedByGroup  {
        param
        (
            [String]
            $InputPath
        )


        $ManagedGroups = Import-CSV -Path C:\Temp\ManagedByGroups.csv

        foreach ($item in $ManagedGroups){
    
            if (!($item.ManagedBy -eq '')) {
    
                $samAccountName = $item.ManagedBy
      
                $user = Get-ADUser -Server $dc -SearchBase $ou -Filter {(SamAccountName -eq $samAccountName)} | Select-Object -ExpandProperty DistinguishedName
      
                Write-Host $User
      
                Set-ADGroup -Server $DC -Identity $item.DistinguishedName -ManagedBy $user -WhatIf
      
            } #End If
    
        }


    }
}

Process {

    if ($Set -eq $False) {
        Get-EmptyManagedByGroups ($OutputPath)
    }


    if ($set) {
        Set-EmptyManagedByGroup ($InputPath)
    }
  
}

End{}

